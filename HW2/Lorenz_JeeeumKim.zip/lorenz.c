#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include <time.h>
#include <math.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#ifdef MSC_VER
#include <crtdbg.h>  /* DUMP MEMORY LEAKS */
#endif


// Number of points to draw in the curves */
#define LORENZ_ITERATOR    1000

// Angle to rotate when the user presses an arrow key */
#define ROTATION_ANGLE  5.0

// Amount to scale bu when the user presses PgUp or PgDn */
#define SCALE_FACTOR     0.8

// Length of print statement on screen
#define LEN 255

double s0 = 10.0, r0 = 28.0, b0 = 2.6666; 
double dt = 0.03;                   
double s = 10.0, r = 28.0, b = 8.0/3.0; 
double lorenz_position[LORENZ_ITERATOR][3]; 
int array_index;                            

double xcen = 0.0, ycen = 0.0, zcen = 0.0;  

int animate = 1;// 0:stop, 1:go, 2:single-step

double red = 0.001;
double blue = 0.001;
double green = 0.001;

void Print(const char* format , ...){
	char	buf[LEN];
	char*	ch = buf;
	va_list args;

	va_start(args, format);
	vsnprintf(buf, LEN, format, args);
	va_end(args);

	while(*ch)
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *ch++);
}
/* The Lorenz Attractor */
void calc_deriv( double position[3], double deriv[3] )
{
    
	deriv[0] = s * (position[1] - position[0] );
    deriv[1] =(r + position[2] ) * position[0] - position[1];
    deriv[2] = -position[0] * position[1] - b * position[2];
}

void advance_in_time(
    double dt, double position[3], double new_position[3]
)
{
    //Move a point along the Lorenz attractor
    double deriv0[3], deriv1[3], deriv2[3], deriv3[3];
    int i;
    //Save the present values
    memcpy(new_position, position, 3 * sizeof(double));

    //First pass in a Fourth-Order Runge-Kutta integration method
    calc_deriv(position, deriv0);
    for( i = 0; i < 3; i++ )
        new_position[i] = position[i] + 0.5 * dt * deriv0[i];

    //Second pass
    calc_deriv(new_position, deriv1);
    for( i = 0; i < 3; i++ )
        new_position[i] = position[i] + 0.5 * dt * deriv1[i];

    // Third pass
    calc_deriv(position, deriv2);
    for( i = 0; i < 3; i++ )
        new_position[i] = position[i] + dt * deriv2[i];

    // Fourth pass
    calc_deriv(new_position, deriv3);
    for( i = 0; i < 3; i++ )
        new_position[i] = position[i] + 0.1666666666666666667 * dt *
            ( deriv0[i] + 2.0 *( deriv1[i] + deriv2[i] ) + deriv3[i] );
}


#define INPUT_LINE_LENGTH 80

void key_cb( unsigned char key, int x, int y )
{
    int i;
    char inputline [INPUT_LINE_LENGTH];

    switch( key )
    {
	// press r/R resets simulation
    case 'r':
    case 'R':
        /* Reset the Lorenz parameters */
        s = s0;
        b = b0;
        r = r0;
        /* Set an initial position */
        lorenz_position[0][0] = rand() / (double)RAND_MAX;
        lorenz_position[0][1] = rand() / (double)RAND_MAX;
        lorenz_position[0][2] = rand() / (double)RAND_MAX;
        array_index = 0;
        
		for( i = 1; i < LORENZ_ITERATOR; i++ )
        {
            memcpy( lorenz_position[i], lorenz_position[0], 3*sizeof( double ) );
        }

        break;

	// press m/M modifies Lorenz
    case 'm':
    case 'M':
        printf("Enter new value of <s> (default %.3f, current %.3f): ", s0, s);
        if(fgets(inputline, INPUT_LINE_LENGTH-1, stdin))
        	sscanf(inputline, "%lf", &s );

        printf("Enter new value of <b> (default %.3f, current %.3f): ", b0, b);
        if(fgets( inputline, INPUT_LINE_LENGTH-1, stdin))
        	sscanf( inputline, "%lf", &b );

        printf("Enter new value of <r> (default %.3f, current %.3f): ", r0, r);
        if(fgets( inputline, INPUT_LINE_LENGTH-1, stdin))
        	sscanf( inputline, "%lf", &r );

        break;

    case 's':
    case 'S':  // Stop the animation
        animate = 0;
        break;

    case 'g':
    case 'G':  // Start the animation
        animate = 1;
        break;

    case ' ':  //Spacebar:  Single step
        animate = 2;
        break;

    case 27:  //esc
   //     glutLeaveMainLoop( );
        break;
    }
}

void special_cb( int key, int x, int y )
{
    switch( key )
    {
    case GLUT_KEY_UP:  //Rotate up
        glRotated( ROTATION_ANGLE, 0.0, 1.0, 0.0 );
        break;

    case GLUT_KEY_DOWN:  // Rotate down
        glRotated( -ROTATION_ANGLE, 0.0, 1.0, 0.0 );
        break;

    case GLUT_KEY_LEFT:  // Rotate left
        glRotated( ROTATION_ANGLE, 0.0, 0.0, 1.0 );
        break;

    case GLUT_KEY_RIGHT:  // Rotate right
        glRotated( -ROTATION_ANGLE, 0.0, 0.0, 1.0 );
        break;

      case GLUT_KEY_F1:
	  	glScaled( 1.0 / SCALE_FACTOR, 1.0 / SCALE_FACTOR, 1.0 / SCALE_FACTOR );
        break;

      case GLUT_KEY_F2:
	  	glScaled( SCALE_FACTOR, SCALE_FACTOR, SCALE_FACTOR );
        break;
    }

    glutPostRedisplay( );
}

void mouse_cb( int button, int updown, int x, int y )
{
    if(updown == GLUT_DOWN)
	  	glScaled( SCALE_FACTOR, SCALE_FACTOR, SCALE_FACTOR );
    if(updown == GLUT_UP)
	  	glScaled( 1.0 / SCALE_FACTOR, 1.0 / SCALE_FACTOR, 1.0 / SCALE_FACTOR );
}

void draw_curve( int index, double position[LORENZ_ITERATOR][ 3 ] )
{
    int i = index;

    glBegin(GL_LINE_STRIP);
	do {
        i = (i == LORENZ_ITERATOR - 1) ? 0 : i + 1;
     	//color variation
		red = (red == 1.0) ? -i*0.001 : 1-i*0.002;
		green = (green == 1.0) ? i*0.003-0.9 : i*0.003+0.1;
		blue = (blue == 1.0) ? 0 : i*0.002 - 0.2;
		
		glColor3d(red, green, blue);
	 	glVertex3dv( position[i] );
    }
    while(i != index);
    glEnd( );

	glBegin(GL_POINTS);
	//draw ball
	glEnd();
}

void display_cb( void )
{
	
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	
	//draw axes
    glBegin( GL_LINES );
    glColor3d( 1.0, 1.0, 1.0 );
    glVertex3d( 0.0, 0.0, 0.0 );
    glVertex3d( 3.0, 0.0, 0.0 );
    glVertex3d( 0.0, 0.0, 0.0 );
    glVertex3d( 0.0, 3.0, 0.0 );
    glVertex3d( 0.0, 0.0, 0.0 );
    glVertex3d( 0.0, 0.0, 3.0 );
    glEnd( );

	//lable axes
	glRasterPos3d(3,0,0);
	Print("X");
	glRasterPos3d(0,3,0);
	Print("Y");
	glRasterPos3d(0,0,3);
	Print("Z");

	//draw lorenz curve
    draw_curve( array_index, lorenz_position );


    glColor3d( 1.0, 1.0, 1.0 );
    glRasterPos2i( 10, 10 );

	glFlush();
    glutSwapBuffers( );
}

void reshape_cb(int width, int height)
{
    double ar;

    glViewport( 0, 0, width, height );
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity( );

	ar =  width * 1.0 / height;
    if( ar > 1.0 )
    	glFrustum( -ar, ar, -1.0, 1.0, 10.0, 100.0 );
    else
    	glFrustum( -1.0, 1.0, -1/ar, 1/ar, 10.0, 100.0 );
    
    xcen = 0.0;
    ycen = 0.0;
    zcen = 0.0;
    glTranslated( xcen, ycen, zcen - 50.0 );
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}


void timer_cb( int value )
{
    // Function called at intervals to update the positions
    int new_index = array_index + 1;

    // Enroll the next timed callback
    glutTimerFunc(30, timer_cb, 0);

    if(animate > 0){
        if( new_index == LORENZ_ITERATOR)
            new_index = 0;
        advance_in_time(
            dt, lorenz_position[array_index], lorenz_position[new_index]
        );
        array_index = new_index;

        if( animate == 2 )
            animate = 0;
    }

    glutPostRedisplay( );
}


int main( int argc, char *argv[] )
{
    int pargc = argc;

    srand(( int )time( NULL ) );

    glEnable( GL_DEPTH_TEST );
    glClearColor( 0.0, 0.0, 0.0, 0.0 );
    glClearDepth( 1.0 );

    glutInitWindowSize( 700, 700 );
    glutInit( &pargc, argv );
    glutInitDisplayMode( GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH );

    glutCreateWindow( "Lorenz Attractor" );
    glutKeyboardFunc( key_cb );
    glutMouseFunc( mouse_cb );
    glutSpecialFunc( special_cb );
    glutDisplayFunc( display_cb );
    glutReshapeFunc( reshape_cb );
    glutTimerFunc( 30, timer_cb, 0 );

    key_cb( 'r', 0, 0 ); //reset for initinalization

    glutMainLoop( );

#ifdef MSC_VER
    _CrtDumpMemoryLeaks( );  /* DUMP MEMORY LEAK INFORMATION */
#endif

    return EXIT_SUCCESS;
}
